# Module version
MODVER=$(grep_prop version $TMPDIR/module.prop)

ui_print "- Подпишись на наш телеграм - t.me/F1NDLE_CN"
ui_print "- Разблокировка 120FPS прошла успешно!"
ui_print "- Спасибо за установку наших модулей"
